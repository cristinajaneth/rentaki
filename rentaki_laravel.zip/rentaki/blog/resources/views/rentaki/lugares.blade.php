@extends('plantillas.plantilla_2')
		
@section('titulo','Lugares')

@section('contenido')


@endsection