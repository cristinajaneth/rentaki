@extends('plantillas.plantilla_2')
		
@section('titulo','Conocenos')

@section('contenido')

<div class="general">
        <div class="seccion">
            <a name=paquetes></a>
            <div class="paquetes">
                <br>
                <br>
                    <h1 style=" color: #471600;" align="center">Paquetes</h1>

                <br>
                <br>
              <div class="row" id="caja">
					<div class="col-6 col-md-6">
	             	 <img id="paq" src="img/p1.jpg" href="#">
              
             </div>   
             <div class="col-6 col-md-6">
                 <img id="paq" src="img/p2.jpg" href="#">
			</div>
		</div>
</div>
</div>
		</div><br>
                <br>
@endsection