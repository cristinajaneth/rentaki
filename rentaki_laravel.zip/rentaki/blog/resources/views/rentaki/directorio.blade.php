@extends('plantillas.plantilla_2')
		
@section('titulo','Directorio')

@section('contenido')


@endsection