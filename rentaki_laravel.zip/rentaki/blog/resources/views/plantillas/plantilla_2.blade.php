<!DOCTYPE html>
<html>
<head>
	<title>@yield('titulo')</title>

<link rel="stylesheet" href="css/bootstrap.min.css"/>
<link href="https://fonts.googleapis.com/css?family=Roboto+Condensed:300,300i,400,400i,700i" rel="stylesheet">

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="css/estilos.css">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
	<link rel="shortcut icon" type="image/png" href="/img/logo.png"/ class="icono">

  <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>


</head>
<body>
	<!-- Navbar -->
  <nav  class="navbar navbar-light navbar navbar-expand-sm justify-content-center" style="background-color: #471600;">
  
   <a class="navbar-brand" href="#"><img id="#img_rentaki" width="10%" src="img/RENTAKI_WHITE-01.png"></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse justify-content-center" id="navbarNavAltMarkupwidth="100%">
    <div class="navbar-nav">
     <a style="color: white;" class="nav-item nav-link active" href="rentaki">Inicio</a>
      <a style="color: white;" class="nav-item nav-link" href="lugares">Lugares</a>
      <a style="color: white;" class="nav-item nav-link" href="directorio">Directorio</a>
      <a style="color: white;" class="nav-item nav-link" href="paquetes">Paquetes</a>
      <a style="color: white;" class="nav-item nav-link" href="contacto">Conocenos</a>
    </div>
  </div>

</nav>

@yield('contenido')


  <footer class="section footer-classic context-dark bg-image" style="background: #471600;">
        <div class="container">
          <div class="row row-30">
            <div class="col-md-4 col-xl-5">
              <div class="pr-xl-4"><a class="brand" href="index.html"><img class="brand-logo-light" src="images/agency/logo-inverse-140x37.png" alt="" width="140" height="37" srcset="images/agency/logo-retina-inverse-280x74.png 2x"></a>
                <h5>Mas informacion de la compañia</h5>
                <p>Rentaki es una futura empresa desarrollada por dos estudiantes de nivel TSU, en el cual se quiere demostrar los conocimientos aprendidos durante el tercer cuatrimestre. Sabias que Rentaki surge de la combinación de las palabras Renta y Aquí</p>
              </div>
            </div>

            <div class="col-md-4">
              <h5>Informacion Contactos</h5>
              <dl class="contact-list">
                <dt>Dirección:</dt>
                <dd>Gutierez Zamora, Veracruz, Mexico</dd>
              </dl>
              <dl class="contact-list">
                <dt>Correo:</dt>
                <dd><a href="mailto:#">rentaki@gmail.com</a></dd>
              </dl>
              <dl class="contact-list">
                <dt>Télefonos:</dt>
                <dd><a>+766-115-3853</a> <span>ó</span> <a>+766-134-6523</a>
                </dd>
              </dl>
            </div>
            <div class="col-md-4 col-xl-3">
              <h5>Redes Sociales</h5>
              <ul class="nav-list">
                <li><a id="btn-facebook" href=""><i class="fab fa-facebook-square"> Facebook</i></a></li>
                <li><a id="btn-twiter" href=""><i class="fab fa-twitter">Twitter</i></a></li>
                <li><a id="btn-instagram" href=""><i class="fab fa-instagram">Instagram</i></a></li>
                
              </ul>
            </div>
          </div>
        </div>
       
      </footer>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<script src="js/rentaki.js'" type="text/javascript"></script>



</body>
</html>