<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::get('rentaki',function(){
	return view('/rentaki.rentaki');
})->name("rentaki");

Route::get('lugares',function(){
	return view('/rentaki.lugares');
})->name('lugares');

Route::get('directorio',function(){
	return view('/rentaki.directorio');
})->name('directorio');

Route::get('paquetes',function(){
	return view('/rentaki.paquetes');
})->name('paquetes');

Route::get('contacto',function(){
	return view('/rentaki.contacto');
})->name('contacto');