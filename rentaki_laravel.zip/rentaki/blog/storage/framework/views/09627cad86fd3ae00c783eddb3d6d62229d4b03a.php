		
<?php $__env->startSection('titulo','Lugares'); ?>

<?php $__env->startSection('contenido'); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantillas.plantilla_2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\rentaki\blog\resources\views//rentaki/lugares.blade.php ENDPATH**/ ?>