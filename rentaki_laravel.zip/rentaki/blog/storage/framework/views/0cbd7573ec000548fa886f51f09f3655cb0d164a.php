		
<?php $__env->startSection('titulo','Conocenos'); ?>

<?php $__env->startSection('contenido'); ?>

<div class="general">
        <div class="seccion">
            <a name=paquetes></a>
            <div class="paquetes">
                <br>
                <br>
                    <h1 style=" color: #471600;" align="center">Paquetes</h1>

                <br>
                <br>
              <div class="row" id="caja">
					<div class="col-6 col-md-6">
	             	 <img id="paq" src="img/p1.jpg">
              
             </div>   
             <div class="col-6 col-md-6">
                 <img id="paq" src="img/p2.jpg">
			</div>
		</div>
</div>
</div>
		</div><br>
                <br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantillas.plantilla_2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\rentaki\blog\resources\views//rentaki/paquetes.blade.php ENDPATH**/ ?>