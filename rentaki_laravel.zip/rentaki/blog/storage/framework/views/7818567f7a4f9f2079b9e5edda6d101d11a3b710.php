		
<?php $__env->startSection('titulo','Conocenos'); ?>

<?php $__env->startSection('contenido'); ?>


                
                	<div class="row" id="caja">
                	<div class="col-6 col-md-6">
              
                <br>
                <br>
                    
            </div>
        
        </div>

    

    <div class="row" id="caja">
	<div class="col-6 col-md-6">
		
	<h1 style=" color: #471600;" align="center">Misión</h1>
                    <br>
                    <p class="text-justify">
                    	Rentaki tiene como misión ayudar a las personas a encontrar la mejor opción de alojamiento y con ello facilitar el proceso de renta a todos nuestros usuarios, en cuanto a seguridad, comodidad y presupuesto se refiere. Utilizamos la tecnología de forma única para favorecer el desarrollo económico de los habitantes de Gutiérrez Zamora y municipios aledaños, quienes pueden monetizar sus espacios, para convertirse en emprendedores de la hospitalidad. Rentaki aparte de que, conecta a las personas, beneficia a todas las partes implicadas, entre las que se encuentran anfitriones, huéspedes, empleados y la economía de las comunidades en las que opera.
                    </p>
                
                 <br>
                
              
                    <h1 style=" color: #471600;" align="center">Visión</h1>
                <br>
              
                <p class="text-justify">
                	Ayudar a millones de usuarios a encontrar su lugar ideal, facilitando el proceso de renta. Buscamos llegar a ser la primera opción de cada persona cuando se encuentre con esta difícil tarea y que puedan encontrar un alojamiento adaptado a sus necesidades desde la comodidad que te brinda un sitio web.
                    </p>
</div>

<div class="col-6 col-md-6">
	<br>
    <img class="img-fluid"  src="img./AVATAR.png">
    <br><br>
	<img class="img-fluid"  src="img./amigos.gif">
	<br><br><br>
</div>


</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantillas.plantilla_2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\rentaki\blog\resources\views//rentaki/contacto.blade.php ENDPATH**/ ?>