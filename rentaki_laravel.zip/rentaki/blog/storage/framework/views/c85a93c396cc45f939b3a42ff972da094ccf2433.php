		
<?php $__env->startSection('titulo','Directorio'); ?>

<?php $__env->startSection('contenido'); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantillas.plantilla_2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\rentaki\blog\resources\views//rentaki/directorio.blade.php ENDPATH**/ ?>